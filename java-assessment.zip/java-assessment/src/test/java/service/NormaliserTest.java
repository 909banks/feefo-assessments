package service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import feefo.interview.model.JobTitle;
import feefo.interview.service.Normaliser;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

public class NormaliserTest {

  private Normaliser underTest;

  @BeforeEach
  void setUp() {
    underTest = new Normaliser();
  }

  @ParameterizedTest
  @ValueSource(strings = {"Accountant", "Architect", "Quantity surveyor", "Software engineer"})
  void givenIdenticalJob_returnMatch(String input) {
    JobTitle expected = JobTitle.valueOfTitle(input);

    String actual = Normaliser.normalise(input);
    assertEquals(expected.getTitle(), actual);
  }

  @ParameterizedTest
  @CsvSource(value = {"Accountant, ACCOUNTANT", "ArchitEct, ARCHITECT", "quantity Surveyor, QUANTITY_SURVEYOR",
      "SOFTWARE ENGINEER, SOFTWARE_ENGINEER"})
  void givenCaseDifference_returnMatch(String input, String expectedEnum) {
    JobTitle expected = JobTitle.valueOf(expectedEnum);

    String actual = Normaliser.normalise(input);
    assertEquals(expected.getTitle(), actual);
  }

  @ParameterizedTest
  @CsvSource(value = {
      "Java Engineer, Software engineer",
      "C# engineer, Software engineer",
      "Software developer, Software engineer",
      "Chief Accountant, Accountant",
      "Junior Accountant, Accountant",
      "System Architect, Architect",
      "landscape architect, Architect",
      "Archetect, Architect",
      "Quantity engineer, Quantity surveyor"
  })
  void givenSimilarJob_returnMatch(String inputJob, String expectedJob) {
    JobTitle expectedEnum = JobTitle.valueOfTitle(expectedJob);

    String actual = Normaliser.normalise(inputJob);
    JobTitle actualEnum = JobTitle.valueOfTitle(actual);
    assertEquals(expectedJob, actual);
    assertEquals(expectedEnum, actualEnum);
  }

  @Test
  void givenValidInputWithRandomString_returnMatch() {
    String randomString = String.valueOf(RandomStringUtils.randomAlphabetic(10));
    String actual = Normaliser.normalise(randomString);

    JobTitle enumValue = JobTitle.valueOfTitle(actual);
    assertNotNull(actual);
    assertNotNull(enumValue);
  }

  @Test
  void givenInvalidInput_returnNull() {
    String actual = Normaliser.normalise("æ¢¢ø↓nŧæŧ");
    assertNull(actual);
  }

  @Test
  void givenNullInput_returnNull() {
    String actual = Normaliser.normalise(null);
    assertNull(actual);
  }

  @Test
  void givenBlankInput_returnNull() {
    String actual = Normaliser.normalise("");
    assertNull(actual);
  }

  @Test
  void givenInputWithPunctuationOnly_returnNull() {
    String actual = Normaliser.normalise("!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~");
    assertNull(actual);
  }

  @Test
  void givenInputWithNumbersOnly_returnNull() {
    String actual = Normaliser.normalise("1234567890");
    assertNull(actual);
  }

}
