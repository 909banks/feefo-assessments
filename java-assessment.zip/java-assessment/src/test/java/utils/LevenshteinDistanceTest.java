package utils;

import static feefo.interview.utils.LevenshteinDistance.calculateDistance;

import org.junit.jupiter.api.Test;

public class LevenshteinDistanceTest {

  @Test
  void givenIdenticalJob_distanceIs0() {
    String input = "Software engineer";
    int actual = calculateDistance(input, input);

    assert(actual == 0);
  }

  @Test
  void givenBlankInput_distanceIsLengthOfKnown() {
    String knownJob = "Software engineer";
    int actual = calculateDistance("", knownJob);

    assert(actual == knownJob.length());
  }

  @Test
  void givenBlankKnown_distanceIsLengthOfInput() {
    String inputJob = "Software engineer";
    int actual = calculateDistance(inputJob, "");

    assert(actual == inputJob.length());
  }

  @Test
  void givenSingleInsert_distanceIs1() {
    String knownJob = "Software engineer";
    String inputJob = knownJob + "r";
    int actual = calculateDistance(inputJob, knownJob);

    assert(actual == 1);
  }

  @Test
  void givenSingleSubstitution_distanceIs1() {
    String knownJob = "Software engineer";
    String inputJob = "Software enginner";
    int actual = calculateDistance(inputJob, knownJob);

    assert(actual == 1);
  }

  @Test
  void givenSingleDelete_distanceIs1() {
    String knownJob = "Software engineer";
    String inputJob = knownJob.substring(1);
    int actual = calculateDistance(inputJob, knownJob);

    assert(actual == 1);
  }

  /**
   * This test adds an additional 3 characters to the beginning of the word
   * And substitutes all 4 of the 'e' characters, so the sum total of the
   * difference between the input and known job titles is 7
   **/
  @Test
  void givenMultipleChanges_distanceIsSum() {
    String knownJob = "Software engineer";
    String inputJob = "123" + knownJob;
    inputJob = inputJob.replaceAll("e", "v");

    int actual = calculateDistance(inputJob, knownJob);

    assert(actual == 7);
  }
}
