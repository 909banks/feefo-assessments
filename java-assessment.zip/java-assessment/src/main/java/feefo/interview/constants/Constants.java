package feefo.interview.constants;

public class Constants {
  public static final String VALID_INPUT_REGEX = "^[\\p{Punct}\\d\\sa-zA-z]*$";
}
