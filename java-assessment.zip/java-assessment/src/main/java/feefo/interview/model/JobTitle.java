package feefo.interview.model;

public enum JobTitle {
  ACCOUNTANT("Accountant"),
  ARCHITECT("Architect"),
  QUANTITY_SURVEYOR("Quantity surveyor"),
  SOFTWARE_ENGINEER("Software engineer");

  private final String title;

  JobTitle(final String title) {
    this.title = title;
  }

  public String getTitle() {
    return title;
  }

  public static JobTitle valueOfTitle(String title) {
    for (JobTitle j : values()) {
      if (j.title.equalsIgnoreCase(title)) {
        return j;
      }
    }
    return null;
  }
}
