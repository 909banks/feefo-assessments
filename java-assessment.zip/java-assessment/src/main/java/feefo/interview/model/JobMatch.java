package feefo.interview.model;

public class JobMatch {
  float score;
  JobTitle title;

  public JobMatch(float score, JobTitle title){
    this.score = score;
    this.title = title;
  }

  public float getScore() {
    return score;
  }

  public String getTitle() {
    return title.getTitle();
  }

  public void setScore(final float score) {
    this.score = score;
  }

  public void setTitle(final JobTitle title) {
    this.title = title;
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }

    if (!(o instanceof JobMatch)) {
      return false;
    }

    JobMatch j = (JobMatch) o;
    return Float.compare(score, j.score) == 0 && title == j.title;
  }

}
