package feefo.interview;

import feefo.interview.service.Normaliser;

import java.util.Arrays;

public class Main {
  public static void main(String[] args) {
    String outputMessage;

    if (args != null) {
      String input = Arrays.toString(args);
      String matchedJob = Normaliser.normalise(input);

      outputMessage = matchedJob == null
          ? "Invalid title entered, could not normalise input"
          : String.format("%s matched to job title %s", input, matchedJob);
    } else {
      outputMessage = "Invalid arguments. Please enter a job title";
    }

    System.out.println(outputMessage);
  }
}