package feefo.interview.service;

import static feefo.interview.constants.Constants.VALID_INPUT_REGEX;

public class Validator {

  /**
   * Performs basic validation on input titles
   * If input is null or does not match regex then return false
   * <p>
   * Input titles must not be null
   * Input must be english alphanumerics
   *
   * @param inputTitle
   */
  public static boolean validate(String inputTitle) {
    if (inputTitle != null) {
      return inputTitle.matches(VALID_INPUT_REGEX);
    }
    return false;
  }
}
