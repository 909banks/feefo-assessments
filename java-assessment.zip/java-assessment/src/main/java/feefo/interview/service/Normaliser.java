package feefo.interview.service;

import static feefo.interview.utils.LevenshteinDistance.calculateDistance;

import feefo.interview.model.JobMatch;
import feefo.interview.model.JobTitle;

public class Normaliser {
  public static String normalise(String inputTitle) {
    if (!Validator.validate(inputTitle)) {
      return null;
    }

    if (inputTitle.isBlank() || inputTitle.matches("^[\\p{Punct}\\d]+$")) {
      return null;
    }

    inputTitle = inputTitle.trim();
    JobTitle exactMatch = JobTitle.valueOfTitle(inputTitle);
    if (exactMatch != null) {
      return exactMatch.getTitle();
    }

    return findClosestMatch(inputTitle);
  }

  public static String findClosestMatch(String inputTitle) {
    JobMatch closestMatch = new JobMatch(0.0F, null);
    float score;
    for (JobTitle knownJob : JobTitle.values()) {
      score = (float)  inputTitle.length() / (inputTitle.length() + calculateDistance(inputTitle, knownJob.getTitle()));

      if (score > closestMatch.getScore()) {
        closestMatch.setScore(score);
        closestMatch.setTitle(knownJob);
      }
    }

    return closestMatch.getTitle();

  }
}
