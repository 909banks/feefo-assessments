package feefo.interview.utils;

import java.util.Collections;
import java.util.List;

public class LevenshteinDistance {

  public static int calculateDistance(String inputJob, String knownJob) {
    int[][] distance = new int[inputJob.length() + 1][knownJob.length() + 1];

    for (int i = 0; i <= inputJob.length(); i++) {
      for (int j = 0; j <= knownJob.length(); j++) {
        if (i == 0) {
          distance[i][j] = j;
        }
        else if (j == 0) {
          distance[i][j] = i;
        }
        else {
          int sub = distance[i-1][j-1] + cost(inputJob.charAt(i-1), knownJob.charAt(j - 1));
          int insert = distance[i-1][j] + 1;
          int delete = distance[i - 1][j] + 1;

          distance[i][j] = Collections.min(List.of(sub, insert, delete));
        }
      }
    }

    return distance[inputJob.length()][knownJob.length()];
  }

  private static int cost(char a, char b) {
    return a == b ? 0 : 1;
  }
}
