import React from 'react';
import PropTypes from 'prop-types'
import styled from 'styled-components';

import AccountTable from '../components/table/account-table';
import SupportWidget from '../components/support/support-widget';

export const AccountOverview = ({data}) => {
  console.log(data);

  return (
    <div className="AccountOverview">
      <div className="HeaderRow">
        <h1 className="PageTitle" data-testid='page-title'>Account Overview</h1>
        <SupportWidget supportContact={data.supportContact}/>
      </div>
      <AccountTable salesData={data.salesOverview} />
    </div>
  );
}

AccountOverview.propTypes = {
  data: PropTypes.shape({
    supportContact: PropTypes.shape({
      name: PropTypes.string.isRequired,
      email: PropTypes.string.isRequired,
      phoneNumber: PropTypes.string,
    }).isRequired,
    salesOverview: PropTypes.shape({
      uploads: PropTypes.number.isRequired,
      successfulUploads: PropTypes.number.isRequired,
      linesAttempted: PropTypes.number.isRequired,
      linesSaved: PropTypes.number.isRequired,
    }).isRequired,
  }).isRequired,
};

export default AccountOverview;