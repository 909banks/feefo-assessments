import { render, screen } from '@testing-library/react';
import AccountOverview from './account-overview';

const baseTestData = {
  supportContact: {
    name: "",
    email: ""
  },
  salesOverview: {
    uploads: 0,
    successfulUploads: 0,
    linesAttempted: 0,
    linesSaved: 0,
  },
};

test('renders all elements', () => {
  render(<AccountOverview data={baseTestData}/>);
  const titleElement = screen.getByTestId('page-title');
  const profileIconElement = screen.getByTestId('profile-icon');
  const supportContactElement = screen.getByTestId('contact-details-table');
  const accountTableElement = screen.getByTestId('account-table');

  expect(titleElement).toBeInTheDocument();
  expect(profileIconElement).toBeInTheDocument();
  expect(supportContactElement).toBeInTheDocument();
  expect(accountTableElement).toBeInTheDocument();
});

