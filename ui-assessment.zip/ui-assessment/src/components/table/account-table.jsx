import React from 'react';
import PropTypes from 'prop-types';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faInfoCircle, faUpload } from '@fortawesome/free-solid-svg-icons';

export const AccountTable = ({ salesData }) => {
  const successfulUploadsPercentage =
    salesData.uploads > 0 && salesData.successfulUploads > 0
      ? Math.min(
          Math.round((salesData.successfulUploads / salesData.uploads) * 100),
          100
        )
      : 0;

  const linesSavedPercentage =
    salesData.linesAttempted > 0 && salesData.linesSaved > 0
      ? Math.min(
          Math.round((salesData.linesSaved / salesData.linesAttempted) * 100),
          100
        )
      : 0;

  return (
    <table className='AccountTable' data-testid='account-table'>
      <thead>
        <tr>
          <th>
            <FontAwesomeIcon icon={faUpload} />
            <b>Sales</b>
          </th>
          <th>
            <FontAwesomeIcon icon={faInfoCircle} />
          </th>
        </tr>
        <tr>
          <th colSpan='2' data-testid='sales-info'>
            <p>
              You had <b>{salesData.uploads} uploads</b> and{' '}
              <b>{salesData.linesSaved}</b> lines added
            </p>
          </th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td data-testid='upload-success'>
            <p className='TableData' data-testid='upload-success-perc'>{successfulUploadsPercentage}%</p>
            <h1 className='InfoHeader'>UPLOAD SUCCESS</h1>
          </td>

          <td data-testid='lines-saved'>
            <p className='TableData' data-testid='lines-saved-perc'>{linesSavedPercentage}%</p>
            <h1 className='InfoHeader'>LINES SAVED</h1>
          </td>
        </tr>
      </tbody>
    </table>
  );
};

AccountTable.propTypes = {
  salesData: PropTypes.shape({
    uploads: PropTypes.number.isRequired,
    successfulUploads: PropTypes.number.isRequired,
    linesAttempted: PropTypes.number.isRequired,
    linesSaved: PropTypes.number.isRequired,
  }).isRequired,
};

export default AccountTable;
