import { render, screen } from '@testing-library/react';
import AccountTable from './account-table';

const baseSalesData = {
  uploads: 0,
  successfulUploads: 0,
  linesAttempted: 0,
  linesSaved: 0,
};

test('should render elements', () => {
  render(<AccountTable salesData={baseSalesData} />);

  const accountTableElement = screen.getByTestId('account-table');
  const salesDataElement = screen.getByTestId('sales-info');
  const uploadSuccessElement = screen.getByTestId('upload-success');
  const linesSavedElement = screen.getByTestId('lines-saved');

  expect(accountTableElement).toBeInTheDocument();
  expect(salesDataElement).toBeInTheDocument();
  expect(uploadSuccessElement).toBeInTheDocument();
  expect(linesSavedElement).toBeInTheDocument();
});

test('provided valid data, calculate percentage', () => {
  const testSalesData = {
    uploads: 4,
    successfulUploads: 3,
    linesAttempted: 10,
    linesSaved: 8,
  };
  render(<AccountTable salesData={testSalesData} />);

  const uploadSuccessElement = screen.getByTestId('upload-success-perc');
  const linesSavedElement = screen.getByTestId('lines-saved-perc');

  expect(uploadSuccessElement).toBeInTheDocument();
  expect(linesSavedElement).toBeInTheDocument();
  expect(uploadSuccessElement).toHaveTextContent('75%');
  expect(linesSavedElement).toHaveTextContent('80%');
});

test('provided 0 data, calculated percentage is 0', () => {
  render(<AccountTable salesData={baseSalesData} />);

  const uploadSuccessElement = screen.getByTestId('upload-success-perc');
  const linesSavedElement = screen.getByTestId('lines-saved-perc');

  expect(uploadSuccessElement).toBeInTheDocument();
  expect(linesSavedElement).toBeInTheDocument();
  expect(uploadSuccessElement).toHaveTextContent('0%');
  expect(linesSavedElement).toHaveTextContent('0%');
});

test('provided negative data, calculated percentage is 0', () => {
  const testSalesData = {
    uploads: -4,
    successfulUploads: -3,
    linesAttempted: -10,
    linesSaved: -8,
  };
  render(<AccountTable salesData={testSalesData} />);

  const uploadSuccessElement = screen.getByTestId('upload-success-perc');
  const linesSavedElement = screen.getByTestId('lines-saved-perc');

  expect(uploadSuccessElement).toBeInTheDocument();
  expect(linesSavedElement).toBeInTheDocument();
  expect(uploadSuccessElement).toHaveTextContent('0%');
  expect(linesSavedElement).toHaveTextContent('0%');
});

test('provided attempted > saved, calculated percentage is 100', () => {
  const testSalesData = {
    uploads: 4,
    successfulUploads: 3,
    linesAttempted: 10,
    linesSaved: 11,
  };
  render(<AccountTable salesData={testSalesData} />);

  const linesSavedElement = screen.getByTestId('lines-saved-perc');
  expect(linesSavedElement).toBeInTheDocument();
  expect(linesSavedElement).toHaveTextContent('100%');
});

test('provided successful > uploads, calculated percentage is 100', () => {
  const testSalesData = {
    uploads: 4,
    successfulUploads: 5,
    linesAttempted: 1,
    linesSaved: 1,
  };
  render(<AccountTable salesData={testSalesData} />);

  const uploadSuccessElement = screen.getByTestId('upload-success-perc');
  expect(uploadSuccessElement).toBeInTheDocument();
  expect(uploadSuccessElement).toHaveTextContent('100%');
});
