import { render, screen } from '@testing-library/react';
import SupportWidget from './support-widget';

const baseTestData = {
    name: 'test user',
    email: 'test@email.com',
}

test('should render base elements', () => {
    render(<SupportWidget supportContact={baseTestData} />);

    const headerElement = screen.getByTestId('widget-header');
    const tableElement = screen.getByTestId('contact-details-table');
    expect(headerElement).toBeInTheDocument();
    expect(tableElement).toBeInTheDocument();
});

test('should render profile icon', () => {
    render(<SupportWidget supportContact={baseTestData} />);
    const iconElement = screen.getByTestId('profile-icon');
    expect(iconElement).toBeInTheDocument();
});

test('should render contact details given required data', () => {
    render(<SupportWidget supportContact={baseTestData} />);

    const contactNameElement = screen.getByText(baseTestData.name);
    const contactEmailElement = screen.getByText(baseTestData.email);
    expect(contactNameElement).toBeInTheDocument();
    expect(contactEmailElement).toBeInTheDocument();

    const phoneNumberElement = screen.queryByTestId('contact-phone-number');
    expect(phoneNumberElement).toBeNull();
});

test('should render phone number if provided', () => {
    const fullTestData = { ...baseTestData, phoneNumber: '07500002936'};
    render(<SupportWidget supportContact={fullTestData} />);

    const phoneNumberElement = screen.getByTestId('contact-phone-number');
    expect(phoneNumberElement).toBeInTheDocument();
});