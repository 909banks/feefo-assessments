import React from 'react'
import PropTypes from 'prop-types'

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEnvelope } from '@fortawesome/free-solid-svg-icons';
import ProfileIcon from './profile-icon';

export const SupportWidget = ({ supportContact }) => {
  return (
    <div>
      <h1 className='InfoHeader' data-testid='widget-header'>
        YOUR FEEFO SUPPORT CONTACT
      </h1>
      <div className='SupportWidget'>
        <ProfileIcon username={supportContact.name} />
        <table className='SupportTable' data-testid='contact-details-table'>
          <thead>
            <tr data-testid='contact-name'>
              <th colSpan={2}>{supportContact.name}</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td data-testid='contact-email'>
                <FontAwesomeIcon icon={faEnvelope} />
                {supportContact.email}
              </td>

              {supportContact.phoneNumber && (
                <td data-testid='contact-phone-number'>
                  {supportContact.phoneNumber}
                </td>
              )}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};

SupportWidget.propTypes = {
  supportContact: PropTypes.shape({
    name: PropTypes.string.isRequired,
    email: PropTypes.string.isRequired,
    phoneNumber: PropTypes.string,
  }).isRequired,
};

export default SupportWidget;