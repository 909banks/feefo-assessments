import { render, screen } from '@testing-library/react';
import ProfileIcon from './profile-icon';

const testUsername = 'test user';

test('should render profile icon', () => {
  render(<ProfileIcon username={testUsername} />);
  const iconElement = screen.getByTestId('profile-icon');
  expect(iconElement).toBeInTheDocument();
})

test('should render first character from username', () => {
  render(<ProfileIcon username={testUsername} />);
  const iconElement = screen.getByText(testUsername.toUpperCase().charAt(0));
  expect(iconElement).toBeInTheDocument();
});

test('provided empty string, render S as icon', () => {
  render(<ProfileIcon username={''} />);
  const iconElement = screen.getByText('S');
  expect(iconElement).toBeInTheDocument();
});