import React from 'react'
import PropTypes from 'prop-types';

export const ProfileIcon = ({ username }) => {
  const iconValue = username.length > 0 ? username.toUpperCase().charAt(0) : 'S';
  
  return (
    <div className='ProfileIcon' data-testid='profile-icon'>
      <p>{iconValue}</p>
    </div>
  );
};

ProfileIcon.propTypes = {
  username: PropTypes.string.isRequired,
};

export default ProfileIcon;